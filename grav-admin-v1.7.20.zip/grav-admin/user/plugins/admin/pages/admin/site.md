---
title: Site Settings
template: config
expires: 0

access:
    admin.configuration.site: true
    admin.super: true
---
